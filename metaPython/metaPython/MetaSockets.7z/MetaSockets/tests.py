from Common import Response
from Common import FakeApiProxy
import ApiV1
import ApiV2

api1 = ApiV1.Api(FakeApiProxy())
api2 = ApiV2.Api(FakeApiProxy())

result1 = api1.createAccount('yoba', 'yobagroup', '1234qwer')
print(result1.result)
print(result1.login)
print(result1.huyPizda)


result2 = api1.createAccount('yoba', 'yobagroup', '1234qwer', comment = 'петух')
print(result2.result)
print(result2.login)
print(result2.huyPizda)


result3 = api2.createAccount(name='yoba', group='yobagroup', password = '1234qwer')
print(result3.result)
print(result3.login)
print(result3.huyPizda)


result4 = api2.createAccount(name='yoba', group='yobagroup', password = '1234qwer', comment = 'петух')
print(result4.result)
print(result4.login)
print(result4.huyPizda)